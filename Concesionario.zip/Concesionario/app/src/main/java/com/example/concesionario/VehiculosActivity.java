package com.example.concesionario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Locale;

public class VehiculosActivity extends AppCompatActivity {

    EditText jetplaca, jetmodelo, jetmarca, jetvalor;
    CheckBox jcbactivo;
    Button jbtanular, jbtguardar;
    ClsOPenHelper admin=new ClsOPenHelper(this,"Concesionario2.db",null,1);
    String placa, modelo, marca, valor;
    long respuesta;
    boolean sw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehiculos);
        //Asociar los objetos Java con los objetos Xml
        jetplaca = findViewById(R.id.etplaca);
        jetmodelo = findViewById(R.id.etmodelo);
        jetmarca = findViewById(R.id.etmarca);
        jetvalor = findViewById(R.id.etvalor);
        jcbactivo = findViewById(R.id.cbactivo);
        jbtanular = findViewById(R.id.btanular);
        jbtguardar = findViewById(R.id.btguardar);
        jbtguardar = findViewById(R.id.btguardar);
        jetplaca.requestFocus();
        sw = false;
        Toast.makeText(this, "Digite la placa y luego consulte", Toast.LENGTH_SHORT).show();
    }// Fin onCreate

    public void consultar(View view){
        placa = jetplaca.getText().toString().toLowerCase();
        //Validar que la placa  se digitó
        if (!placa.isEmpty()) {
            SQLiteDatabase db = admin.getReadableDatabase();
            Cursor registro = db.rawQuery("select * from TblVehiculo where Placa='" + placa + "'", null);
            if (registro.moveToNext()){
                sw=true;
                jbtanular.setEnabled(true);
                jetmodelo.setText(registro.getString(1));
                jetmarca.setText(registro.getString(2));
                jetvalor.setText(registro.getString(3));
                if(registro.getString(4).equals("Si"))
                    jcbactivo.setChecked(true);
                else
                    jcbactivo.setChecked(false);
            }else{
                Toast.makeText(this, "Vehículo no registrado", Toast.LENGTH_SHORT).show();
                jcbactivo.setChecked(true);
            }
            jetmodelo.setEnabled(true);
            jetmarca.setEnabled(true);
            jetvalor.setEnabled(true);
            jbtguardar.setEnabled(true);
            jetplaca.setEnabled(false);
            jetmodelo.requestFocus();
            db.close();

        }else{
            Toast.makeText(this, "La placa es requerida", Toast.LENGTH_SHORT).show();
            jetplaca.requestFocus();
        }
    }// Fin método consultar

    public void guardar(View view){
        //Validar que los campos no esten vacios
        placa = jetplaca.getText().toString().toLowerCase();
        modelo = jetmodelo.getText().toString();
        marca= jetmarca.getText().toString();
        valor = jetvalor.getText().toString();
        if (placa.isEmpty() || modelo.isEmpty() || marca.isEmpty() || valor.isEmpty()) {
            Toast.makeText(this, "Todos los datos son requeridos", Toast.LENGTH_SHORT).show();
            jetplaca.requestFocus();
        }else {
            SQLiteDatabase db = admin.getWritableDatabase();

            ContentValues fila = new ContentValues();
            //Llenar el contenedor
            fila.put("Placa", placa);
            fila.put("Modelo", modelo);
            fila.put("Marca", marca);
            fila.put("Valor", valor);

            if (sw == false)
                respuesta = db.insert("TblVehiculo", null, fila);
            else
                sw = false;
            respuesta = db.update("TblVehiculo", fila, "Placa='" + placa + "'", null);

        if (respuesta > 0) {
            Toast.makeText(this, "Registro guardado", Toast.LENGTH_SHORT).show();
            Limpiar_campos();
        }else
            Toast.makeText(this, "Error guardando registro", Toast.LENGTH_SHORT).show();
            db.close();
        }
    }//Fin método guardar

    public void anular(View view){
        SQLiteDatabase db = admin.getReadableDatabase();
        ContentValues fila = new ContentValues();
        fila.put("Activo","No");
        respuesta = db.update("TblVehiculo", fila, "Placa='" + placa + "'", null);
        if (respuesta > 0){
            Toast.makeText(this, "Registro anulado", Toast.LENGTH_SHORT).show();
            Limpiar_campos();
        }else
            Toast.makeText(this, "Error guardando registro", Toast.LENGTH_SHORT).show();
        db.close();

    }//Fin metodo anular

    public void limpiar(View view){
        Limpiar_campos();
    }

    public void listar(View view){
        Intent intlistar = new Intent(this,ListarVehiculosActivity.class);
        startActivity(intlistar);
    }//Fin de metodo listar


    public void regresar(View view){
        Intent intmain =new Intent(this, MainActivity.class);
        startActivity(intmain);
    }



    private void Limpiar_campos() {
        jetplaca.setText("");
        jetmodelo.setText("");
        jetmarca.setText("");
        jetvalor.setText("");
        jcbactivo.setChecked(false);
        jetplaca.setEnabled(true);
        jetplaca.requestFocus();
        jetmodelo.setEnabled(false);
        jetmarca.setEnabled(false);
        jetmodelo.setEnabled(false);
        jbtguardar.setEnabled(false);
        jbtanular.setEnabled(false);
        sw = false;
    }

}