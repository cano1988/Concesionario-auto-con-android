package com.example.concesionario;

public class ClsRegistroCliente {

    private String identificacion;
    private String nombre;
    private String direccion;
    private String telefono;
    private String activo;

    public ClsRegistroCliente(String identificacion, String nombre, String direccion,
                              String telefono, String activo) {
        this.identificacion = identificacion;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.activo = activo;
    }//Fin del constructor



    @Override
    public String toString() {
        return
                "Identificacion: " + identificacion + '\n' +
                "Nombre: " + nombre + '\n' +
                "Direccion: " + direccion + '\n' +
                "Telefono: " + telefono + '\n' +
                "Activo: " + activo + '\n';
    }
}
