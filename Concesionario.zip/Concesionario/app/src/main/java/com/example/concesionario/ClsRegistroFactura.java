package com.example.concesionario;

public class ClsRegistroFactura {
    private String codigo ;
    private String fecha;
    private String identificacion;
    private String activo;

    public ClsRegistroFactura(String codigo, String fecha, String identificacion, String activo) {
        this.codigo = codigo;
        this.fecha = fecha;
        this.identificacion = identificacion;
        this.activo = activo;
    }

    @Override
    public String toString() {
        return "ClsRegistroFactura{" +
                "codigo='" + codigo + '\'' +
                ", fecha='" + fecha + '\'' +
                ", identificacion='" + identificacion + '\'' +
                ", activo='" + activo + '\'' +
                '}';
    }
}
