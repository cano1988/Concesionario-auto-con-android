package com.example.concesionario;

import java.text.DecimalFormat;

public class ClsRegistroVehiculo {

    private String placa;
    private String modelo;
    private String marca;
    private String  valor;
    private String activo;




    public ClsRegistroVehiculo(String placa, String modelo, String marca, String valor, String activo) {
        this.placa = placa;
        this.modelo = modelo;
        this.marca = marca;
        this.valor = valor;
        this.activo = activo;
    }

    @Override
    public String toString() {
        return
                "Placa: " + placa + '\n' +
                "Modelo: " + modelo + '\n' +
                "Marca: " + marca + '\n' +
                "Valor: " + valor + '\n' +
                "Activo: " + activo;

    }
}
