package com.example.concesionario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ListarFacturasActivity extends AppCompatActivity {

    ListView lvfactura;
    ArrayList<ClsRegistroFactura> alfactura = new ArrayList<>();
    ArrayAdapter<ClsRegistroFactura> aafacturas;
    ClsOPenHelper admin=new ClsOPenHelper(this,"Concesionario2.db",null,1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_facturas);
        //Asociar objetos java con objetos xml
        lvfactura = findViewById(R.id.lvfactura);
        //Abrir la conxion en modo lectura y relaizar la consulta
        SQLiteDatabase db=admin.getReadableDatabase();
        Cursor registro=db.rawQuery("Select * from TblFactura",null);
        //llenar el array list
        for(int k=0; k < registro.getCount(); k++){
            registro.moveToNext();
            ClsRegistroFactura objregistro = new ClsRegistroFactura(registro.getString(0),
                    registro.getString(1),registro.getString(2),
                    registro.getString(3));
            alfactura.add(objregistro);
        }//Fin proceso de llenado de registros
        //llevar la información del ArrayList al ArrayAdapter
        aafacturas = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,alfactura);
        lvfactura.setAdapter(aafacturas);
        db.close();
    }//fin del metodo onCreate

    public void Regresarf(View view){

        Intent intfactura = new Intent(this, FacturasActivity.class);
        startActivity(intfactura);
    }

}