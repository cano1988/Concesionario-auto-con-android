package com.example.concesionario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ListarVehiculosActivity extends AppCompatActivity {

    ListView lvvehiculos;
    ArrayList<ClsRegistroVehiculo> alvehiculos = new ArrayList<>();
    ArrayAdapter<ClsRegistroVehiculo> aavehiculos;
    ClsOPenHelper adm=new ClsOPenHelper(this,"Concesionario2.db",null,1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_vehiculos);
        //Asociar objetos java con objetos xml
        lvvehiculos = findViewById(R.id.lvvehiculos);
        //Abrir la conxion en modo lectura y relaizar la consulta
        SQLiteDatabase db=adm.getReadableDatabase();
        Cursor regis=db.rawQuery("Select * from TblVehiculo",null);
        for(int k=0; k < regis.getCount(); k++) {
            regis.moveToNext();
            ClsRegistroVehiculo objregistro = new ClsRegistroVehiculo(regis.getString(0).toLowerCase(),
                    regis.getString(1),regis.getString(2),
                    regis.getString(3),regis.getString(4));
            alvehiculos.add(objregistro);
        }//Fin proceso de llenado de registros
        aavehiculos = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1,alvehiculos);
        lvvehiculos.setAdapter(aavehiculos);
        db.close();
    }//fin del metodo onCreate
    public void regresar(View view){
        Intent intvehiculos = new Intent(this, VehiculosActivity.class);
        startActivity(intvehiculos);
    }

}